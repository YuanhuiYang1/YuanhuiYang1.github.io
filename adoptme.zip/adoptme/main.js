function toggleMenu(){
    var nav = document.getElementById('nav');
    nav.classList.toggle('nav-expanded');
    console.log("buttonpress");
}
